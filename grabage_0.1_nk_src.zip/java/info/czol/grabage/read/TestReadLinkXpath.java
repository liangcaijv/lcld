package info.czol.grabage.read;

import info.czol.grabage.bean.GrabageSite;

import java.io.IOException;
import java.util.List;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

/**
 * Ϊ���ɼ�������ש���ߣ��ṩ�ͻ��˵�����ƽ̨ 
 * @���� Gabriel 
 * @���� http://blog.csdn.net/zdsdiablo
 */
public class TestReadLinkXpath {

	private final WebClient webClient;

	private GrabageSite xconfig;

	public TestReadLinkXpath(GrabageSite xconfig) {
		this.xconfig = xconfig;
		webClient = new WebClient(BrowserVersion.INTERNET_EXPLORER_8);
		webClient.setJavaScriptEnabled(false);
		//webClient.setCssEnabled(false);
	}

	public void tryToLoadXlink() throws IOException {
		long lasting = System.currentTimeMillis();
		String link = xconfig.getLink();
		HtmlPage page = (HtmlPage) webClient.getPage(link);
		List<DomNode> nodes = (List<DomNode>) page.getByXPath(xconfig.getXlink());
		for (DomNode node : nodes) {
			String href = node.getAttributes().getNamedItem("href")
					.getNodeValue();
			if (href.startsWith(xconfig.getForward())) {
				System.out.println(node.asText() + "\t" + href);
			}else{
				System.out.println(node.asText() + "\t"+xconfig.getForward()+href);
			}
		}
		System.out.println("get links cost "+(System.currentTimeMillis()-lasting)/1000+"'s");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		GrabageSite xconfig = new GrabageSite();
		xconfig.setXlink("//table[@class='box']//a[@href]");
		xconfig.setLink("http://portal.czol.info/news/money");
		xconfig.setForward("http://portal.czol.info");
		TestReadLinkXpath test = new TestReadLinkXpath(xconfig);
		test.tryToLoadXlink();
	}

}
