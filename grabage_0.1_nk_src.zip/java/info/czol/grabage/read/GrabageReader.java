package info.czol.grabage.read;

import info.czol.grabage.bean.GrabageSite;
import info.czol.grabage.bean.PageInfo;
import info.czol.grabage.bean.PageInfoMark;
import info.czol.grabage.logic.UtilTools;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

/**
 * Ϊ���ɼ�������ש���ߣ��ṩ�ͻ��˵�����ƽ̨ 
 * @���� Gabriel 
 * @���� http://blog.csdn.net/zdsdiablo
 */
public class GrabageReader {
	
	private static final int DEBUG_COUNT=5;
	
	private static final String ENABLED="enabled";
	private static final String HREF="href";

	private static final String CONFIGFILEPATH = "grabage-config.xml";
	
	private final WebClient webClient;
	
	private List<GrabageSite> grabageSites;
	
	public GrabageReader() {
		webClient= new WebClient(BrowserVersion.INTERNET_EXPLORER_8);
		webClient.setJavaScriptEnabled(false);
		grabageSites= new ArrayList<GrabageSite>();
	}

	//���¼��ض�����Ϣ
	public void reLoadSubConfig() {
		long lasting = System.currentTimeMillis();
		System.out.println("[config]start:"+lasting);
		try {
			InputStream is = this.getClass().getClassLoader().getResourceAsStream(CONFIGFILEPATH);
			SAXReader reader = new SAXReader();
			Document doc = reader.read(is);
			Element root = doc.getRootElement();
			//����htmlunit����
			Element configItem = root.element(PageInfoMark.CONFIG.toString());
			//String version = configItem.element("browser").attributeValue("version").trim();
			String jsenabled = configItem.element(PageInfoMark.JAVASCRIPT.toString()).attributeValue(ENABLED).trim();
			webClient.setJavaScriptEnabled(Boolean.parseBoolean(jsenabled));
			
			//�����ɼ�վ�������
			List<Element> gaItems = root.element(PageInfoMark.GRABAGE_ARRAY.toString()).elements(PageInfoMark.GRABAGE.toString());
			grabageSites.clear();
			
			for(Element gaItem : gaItems){
				GrabageSite gs = new GrabageSite();
				gs.setUsable(gaItem.attributeValue(PageInfoMark.USABLE.toString()).trim());
				gs.setForward(gaItem.attributeValue(PageInfoMark.FORWARD.toString()).trim());
				gs.setLink(gaItem.attributeValue(PageInfoMark.LINK.toString()).trim());
				//
				Element title = gaItem.element(PageInfoMark.TITLE.toString());
				if(title!=null) gs.setTitle(title.attributeValue(PageInfoMark.XPATH.toString()));
				
				Element author = gaItem.element(PageInfoMark.AUTHOR.toString());
				if(author!=null) gs.setAuthor(author.attributeValue(PageInfoMark.XPATH.toString()));
				
				Element source = gaItem.element(PageInfoMark.SOURCE.toString());
				if(source!=null) gs.setSource(source.attributeValue(PageInfoMark.XPATH.toString()));
				
				Element timeline = gaItem.element(PageInfoMark.TIMELINE.toString());
				if(timeline!=null) gs.setTimeline(timeline.attributeValue(PageInfoMark.XPATH.toString()));
				
				Element summary = gaItem.element(PageInfoMark.SUMMARY.toString());
				if(summary!=null) gs.setSummary(summary.attributeValue(PageInfoMark.XPATH.toString()));
				
				Element content = gaItem.element(PageInfoMark.CONTENT.toString());
				if(content!=null) gs.setContent(content.attributeValue(PageInfoMark.XPATH.toString()));
				
				Element splitpath = gaItem.element(PageInfoMark.SPLIT.toString());
				if(splitpath!=null) gs.setSplitpath(splitpath.attributeValue(PageInfoMark.XPATH.toString()));
				
				//��ʱֻ��һ�㣬�����Ͽɶ������
				Element xlink = gaItem.element(PageInfoMark.XLINK.toString());
				if(xlink!=null) gs.setXlink(xlink.attributeValue(PageInfoMark.XPATH.toString()));
				
				grabageSites.add(gs);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		lasting = System.currentTimeMillis();
		System.out.println("[config]complete:"+lasting);
	}
	
	public void startReadPage(){
		long lasting = System.currentTimeMillis();
		System.out.println("[grabage]start:"+lasting);
		try {
			List<PageInfo> pbList = reloadPageConfig();
			
			for(PageInfo pb : pbList){
				System.out.println("link:"+pb.getLink()+"\ttitle:"+pb.getTitle());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		lasting = System.currentTimeMillis();
		System.out.println("[grabage]complete:"+lasting);
	}
	
	//���¶�ȡҳ��ץȡ����
	private List<PageInfo> reloadPageConfig() throws Exception{
		List<PageInfo> pbList = new ArrayList<PageInfo>();
		
		HtmlPage page = null;
		for(GrabageSite gsite : grabageSites){
			if(UtilTools.isNotEmpty(gsite.getUsable()) && gsite.getUsable().equals("false")) continue;
			System.out.println(">>>LINK>>>"+gsite.getLink());
			
			page = (HtmlPage)webClient.getPage(gsite.getLink());
			//��������
			HashSet<String> linkSet = new HashSet<String>();
			
			List<DomNode> linkNodes = (List<DomNode>)page.getByXPath(gsite.getXlink());			
			if(linkNodes!=null && !linkNodes.isEmpty()) for(DomNode node : linkNodes){
				String href = node.getAttributes().getNamedItem(HREF).getNodeValue();
				
				if (href.startsWith(gsite.getForward())) {
					linkSet.add(href);
				}
				//ȡ���ⲿ����
				else if(href.startsWith("http:") || href.startsWith("https:")){
					continue;
				}
				//�����������
				else{
					linkSet.add(gsite.getForward()+href);
				}
			}
			int i=0;
			for(String link : linkSet){
				i++;
				if(i>DEBUG_COUNT) break;
				PageInfo pb = new PageInfo();
				pb.setLink(link);
				try{
					page = (HtmlPage)webClient.getPage(pb.getLink());
					//�Ƴ����
					removeAdvert(page,gsite);
					//����
					pb.setTitle(getNodeValue(page, gsite.getTitle()));
					//����
					pb.setAuthor(getNodeValue(page, gsite.getAuthor()));
					//��Դ
					pb.setSource(getNodeValue(page, gsite.getSource()));
					//����ʱ��
					pb.setTimeline(UtilTools.getTimeLine(
							getNodeValue(page, gsite.getTimeline())));
					//���
					pb.setSummary(getNodeValue(page, gsite.getSummary()));
					//����
					pb.setContent(getNodeValues(page, gsite.getContent()));
					
					//��ҳ
					searchNextPage(page,pb,gsite);
					
					pbList.add(pb);
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}
			
		}
		return pbList;
	}
	
	/**
	 * �Ƴ����λ
	 * @param page
	 * @param gsite
	 */
	private void removeAdvert(HtmlPage page,GrabageSite gsite){
		if(gsite.hasAdvert()){
			HashSet<DomNode> adset = new HashSet<DomNode>();
			for(String xadvert : gsite.getAdvert()){
				adset.addAll((List<DomNode>)page.getByXPath(xadvert));
			}
			for(DomNode node : adset){
				try{
					DomNode pnode = node.getParentNode();
					pnode.removeChild(node);
				}catch(Exception ex){
					//������Ƕ�׹��������������쳣
					ex.printStackTrace();
				}
			}
		}
		
	}
	
	/**
	 * Ѱ�Ҵ�ҳ
	 * @param page
	 * @param pb
	 * @param gsite
	 */
	private void searchNextPage(HtmlPage page,PageInfo pb, GrabageSite gsite){
		if(UtilTools.isNotEmpty(gsite.getSplitpath())){
			String href=getNodeHref(page,gsite.getSplitpath());			
			if(UtilTools.isEmpty(href))	return;
			String nextlink="";
			if (href.startsWith(gsite.getForward())) {
				nextlink=href;
			}else{
				nextlink=gsite.getForward()+href;
			}
			try{
				page = (HtmlPage) webClient.getPage(nextlink);
				pb.setContent(pb.getContent()+getNodeValues(page, gsite.getContent()));
				
				searchNextPage(page,pb,gsite);
			}catch(Exception ex){
				return;
			}
		}
	}
	
	private String getNodeHref(HtmlPage page, String xpath){
		if(UtilTools.isEmpty(xpath))
			return "";
		List<DomNode> nodes = (List<DomNode>)page.getByXPath(xpath);
		if(nodes!=null && !nodes.isEmpty()) for(DomNode node : nodes){
			if(node.getAttributes().getLength()>0){
				return node.getAttributes().getNamedItem(HREF).getNodeValue();
			}
		}
		return "";
	}
	
	private String getNodeValue(HtmlPage page, String xpath){
		if(UtilTools.isEmpty(xpath))
			return "";
		List<DomNode> nodes = (List<DomNode>)page.getByXPath(xpath);
		if(nodes!=null && !nodes.isEmpty()) for(DomNode node : nodes){
			if(UtilTools.isNotEmpty(node.asText())){
				return node.asText().trim();
			}
		}
		return "";
	}
	
	private String getNodeValues(HtmlPage page, String xpath){
		if(UtilTools.isEmpty(xpath))
			return "";
		String str="";
		List<DomNode> nodes = (List<DomNode>)page.getByXPath(xpath);
		if(nodes!=null && !nodes.isEmpty()) for(DomNode node : nodes){
			if(UtilTools.isNotEmpty(node.asText())){
				str+=node.asText().trim();
			}
		}
		return str;
	}
	
}