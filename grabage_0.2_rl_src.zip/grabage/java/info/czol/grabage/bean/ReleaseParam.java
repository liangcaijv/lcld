package info.czol.grabage.bean;

public class ReleaseParam {
	private String name;
	private String from;
	private String value;
	
	public ReleaseParam(){
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
